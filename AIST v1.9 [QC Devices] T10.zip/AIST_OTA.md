### AIST v1.8 - 10.05.2023

* Sound changes
  * Fix Fixing 96 or 192 kHz
  * Updated Bluetooth Parametrs
  * Updated Dolby Parametrs
  * Improved Stability
  * Fix Surround Effect
  * Fix Mixer Error
  * Add New Sound Parameters
  * Fix Microphone
  * Fix Direct Output
  * OFF LeAudio (So far it only makes the sound worse)
  * New option for Xiaomi and BBK
  * BBK Group Devices Support
  * Minor edits
* In item Other
  * Improved system smoothness
  * New Camera Parametrs
  * New Systems Parametrs
  * Removed waste parameters
  * Updated Radio(Modem) Parametrs
  * Fixed excessive battery consumption
  * Added new options for MIUI
  * FIX OFF Logging
  * Minor edits
* General
  * Fix Code
  * Fix Some Error
  * Minor edits
