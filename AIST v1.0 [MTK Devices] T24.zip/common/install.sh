
AIST_proc() {
  local Name0=$(echo "$3" | sed -r "s|^.*/.*\[@(.*)=\".*\".*$|\1|")
  local Value0=$(echo "$3" | sed -r "s|^.*/.*\[@.*=\"(.*)\".*$|\1|")
  [ "$(echo "$4" | grep '=')" ] && Name1=$(echo "$4" | sed "s|=.*||") || local Name1="value"
  local Value1=$(echo "$4" | sed "s|.*=||")
  case $1 in
  "-s"|"-u"|"-i")
    local SNP=$(echo "$3" | sed -r "s|(^.*/.*)\[@.*=\".*\".*$|\1|")
    local NP=$(dirname "$SNP")
    local SN=$(basename "$SNP")
	if [ "$5" ]; then
      [ "$(echo "$5" | grep '=')" ] && local Name2=$(echo "$5" | sed "s|=.*||") || local Name2="value"
      local Value2=$(echo "$5" | sed "s|.*=||")
	fi
	if [ "$6" ]; then
      [ "$(echo "$6" | grep '=')" ] && local Name3=$(echo "$6" | sed "s|=.*||") || local Name3="value"
      local Value3=$(echo "$6" | sed "s|.*=||")
	fi
	if [ "$7" ]; then
      [ "$(echo "$7" | grep '=')" ] && local Name4=$(echo "$7" | sed "s|=.*||") || local Name4="value"
      local Value4=$(echo "$7" | sed "s|.*=||")
	fi
  ;;
  esac
  case "$1" in
    "-d") xmlstarlet ed -L -d "$3" "$2";;
    "-u") xmlstarlet ed -L -u "$3/@$Name1" -v "$Value1" "$2";;
    "-s")
  	if [ "$(xmlstarlet sel -t -m "$3" -c . "$2")" ]; then
        xmlstarlet ed -L -u "$3/@$Name1" -v "$Value1" "$2"
      else
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -r "$SNP-$MODID" -v "$SN" "$2"
  	fi;;
    "-i")
  	if [ "$(xmlstarlet sel -t -m "$3[@$Name1=\"$Value1\"]" -c . "$2")" ]; then
        xmlstarlet ed -L -d "$3[@$Name1=\"$Value1\"]" "$2"
  	fi
  	if [ -z "$Value3" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      elif [ "$Value4" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -i "$SNP-$MODID" -t attr -n "$Name3" -v "$Value3" \
        -i "$SNP-$MODID" -t attr -n "$Name4" -v "$Value4" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      elif [ "$Value3" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -i "$SNP-$MODID" -t attr -n "$Name3" -v "$Value3" \
        -r "$SNP-$MODID" -v "$SN" "$2"
  	fi
      ;;
  esac
}

MPATHS="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "*audio_device*.xml")"
APINF="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "*audio_policy*.conf")"
ACONFS="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "AudioParamOptions*.xml")"
APCXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "audio_policy_configuration*.xml")"
A2DPXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "a2dp*.xml")"
DEVF="$(find /system/etc/device_features /vendor/etc/device_features /system_ext/etc/device_features /product/etc/device_features /odm/etc/device_features /my_product/etc/device_features /mi_ext/etc/device_features -type f -name "*.xml")"
MEDCA="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "media_codecs*audio.xml")"
DAXXML="$(find /system/etc/dolby /vendor/etc/dolby /system_ext/etc/dolby /product/etc/dolby /odm/etc/dolby /my_product/etc/dolby /mi_ext/etc/dolby -type f -name "*.xml")"
LOG=$MODPATH/common/other

mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/

  for ODAXXML in ${DAXXML}; do
	DAXXM="$MODPATH$(echo $ODAXXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$ODAXXML $DAXXM
	sed -i 's/\t/  /g' $DAXXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d; /^ *#/d; /^ *$/d' $DAXXM
	sed -i 's/low-filter-mode value="1"/low-filter-mode value="0"/g' $DAXXM
	sed -i 's/band-filter-mode value="1"/band-filter-mode value="0"/g' $DAXXM
	sed -i 's/middle-filter-mode value="1"/middle-filter-mode value="0"/g' $DAXXM
	sed -i 's/height-filter-mode value="1"/height-filter-mode value="0"/g' $DAXXM
	sed -i 's/volume-leveler-compressor-enable value="true"/volume-leveler-compressor-enable value="false"/g' $DAXXM
	sed -i 's/hearing-protection-enable value="true"/hearing-protection-enable value="false"/g' $DAXXM
	sed -i 's/regulator-speaker-dist-enable value="true"/regulator-speaker-dist-enable value="false"/g' $DAXXM
	sed -i 's/bass-mbdrc-enable value="true"/bass-mbdrc-enable value="false"/g' $DAXXM
	sed -i 's/bass-extraction-enable value="true"/bass-extraction-enable value="false"/g' $DAXXM
	sed -i 's/reverb-suppression-enable value="true"/reverb-suppression-enable value="false"/g' $DAXXM
	sed -i 's/audio-optimizer-enable value="true"/audio-optimizer-enable value="false"/g' $DAXXM
	sed -i 's/regulator-sibilance-suppress-enable value="true"/regulator-sibilance-suppress-enable value="false"/g' $DAXXM
	sed -i 's/ieq-enable value="true"/ieq-enable value="false"/g' $DAXXM
	sed -i 's/complex-equalizer-enable value="true"/complex-equalizer-enable value="false"/g' $DAXXM
	sed -i 's/virtual-bass-process-enable value="true"/virtual-bass-process-enable value="false"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="1"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="2"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="3"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="4"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="5"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="6"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="7"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="8"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="9"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="10"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="11"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="12"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="13"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="14"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="15"/global_setting virtual_bass_process="0"/g' $DAXXM
#	sed -i 's/virtualizer-enable value="false"/virtualizer-enable value="true"/g' $DAXXM
	sed -i 's/bass-enhancer-enable value="false"/bass-enhancer-enable value="true"/g' $DAXXM
	sed -i 's/graphic-equalizer-enable value="false"/graphic-equalizer-enable value="true"/g' $DAXXM
	sed -i 's/surround-decoder-enable value="false"/surround-decoder-enable value="true"/g' $DAXXM
	sed -i 's/volume-leveler-enable value="false"/volume-leveler-enable value="true"/g' $DAXXM
	sed -i 's/tuned_rate="48000"/tuned_rate="384000"/g' $DAXXM
	sed -i '/^ *#/d; /^ *$/d' $DAXXM
	done

  for OAPINF in ${APINF}; do
	AAPINF="$MODPATH$(echo $OAPINF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OAPINF $AAPINF
	sed -i 's/\t/  /g' $AAPINF
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d; /^ *#/d; /^ *$/d' $AAPINF
	sed -i '/^ *#/d; /^ *$/d' $AAPINF
	done

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$ODEVF $AODEVF
	sed -i 's/\t/  /g' $AODEVF
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d; /^ *#/d; /^ *$/d' $AODEVF
	sed -i 's/name="btdebug_enabled">true</name="btdebug_enabled">false</g' $AODEVF
	sed -i 's/name="support_ble_oobhelper">false</name="support_ble_oobhelper">true</g' $AODEVF
	sed -i 's/name="support_record_param">false</name="support_record_param">true</g' $AODEVF
	sed -i 's/name="support_interview_record_param">false</name="support_interview_record_param">true</g' $AODEVF
	sed -i 's/name="support_hd_record_param">false</name="support_hd_record_param">true</g' $AODEVF
	sed -i 's/name="support_voip_record">false</name="support_voip_record">true</g' $AODEVF
	sed -i 's/name="support_dolby">false</name="support_dolby">true</g' $AODEVF
	sed -i 's/name="support_hifi">false</name="support_hifi">true</g' $AODEVF
	sed -i 's/name="support_lhdc_offload">false</name="support_lhdc_offload">true</g' $AODEVF
	sed -i 's/name="support_a2dp_latency">false</name="support_a2dp_latency">true</g' $AODEVF
	sed -i 's/name="support_sound_assist">false</name="support_sound_assist">true</g' $AODEVF
	sed -i 's/name="support_new_silentmode">false</name="support_new_silentmode">true</g' $AODEVF
	sed -i 's/name="support_24bit_record">false</name="support_24bit_record">true</g' $AODEVF
	sed -i 's/name="support_audio_loopback">false</name="support_audio_loopback">true</g' $AODEVF
	sed -i 's/name="support_adv_audio_unicast">true</name="support_adv_audio_unicast">false</g' $AODEVF
	sed -i 's/name="support_adv_audio_bca">true</name="support_adv_audio_bca">false</g' $AODEVF
	sed -i 's/name="support_adv_audio_bcs">true</name="support_adv_audio_bcs">false</g' $AODEVF
	sed -i 's/name="support_camera_audio_focus">false</name="support_camera_audio_focus">true</g' $AODEVF
	sed -i 's/name="support_audio_share">false</name="support_audio_share">true</g' $AODEVF
	sed -i '/<features>/a\
	<bool name="support_voip_record">true</bool>\
	<bool name="support_ble_oobhelper">true</bool>\
	<bool name="support_audio_share">true</bool>\
	<bool name="support_24bit_record">true</bool>' $AODEVF
	sed -i '/^ *#/d; /^ *$/d' $AODEVF
	done


	ui_print "***************************************************"
	ui_print "*             [Install Other Tweaks]              *"
	ui_print "***************************************************"
	ui_print "*                 !!!Attention!!!                 *"
	ui_print "*     These Tweaks are NOT Related To SOUND!!!    *"
	ui_print "*                I added for myself               *"
	ui_print "*            suitable for all devices             *"
	ui_print "*  Includes Camera, Modem, Display, System & Etc  *"
	ui_print "***************************************************"
	ui_print "*             [Install Other Tweaks?]             *"
	ui_print "*         [Vol Up = YES | Vol Down = NO]          *"
	ui_print "***************************************************"

if $VKSEL; then

	ui_print "*          ->[Installing Other Tweaks]<-          *"
	ui_print "***************************************************"

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $AODEVF
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d; /^ *#/d; /^ *$/d' $AODEVF
	sed -i 's/name="is_xiaomi">false</name="is_xiaomi">true</g' $AODEVF
	sed -i 's/name="is_xiaomi_device">false</name="is_xiaomi_device">true</g' $AODEVF
	sed -i 's/name="support_my_device">false</name="support_my_device">true</g' $AODEVF
	sed -i 's/name="support_erase_external_storage">false</name="support_erase_external_storage">true</g' $AODEVF
	sed -i 's/name="support_touchfeature_gamemode">false</name="support_touchfeature_gamemode">true</g' $AODEVF
#	sed -i 's/name="support_touch_sensitive">false</name="support_touch_sensitive">true</g' $AODEVF
	sed -i 's/name="support_force_touch">false</name="support_force_touch">true</g' $AODEVF
	sed -i 's/name="support_hide_discoverable">true</name="support_hide_discoverable">false</g' $AODEVF
	sed -i 's/name="support_agps">false</name="support_agps">true</g' $AODEVF
	sed -i 's/name="support_agps_paras">false</name="support_agps_paras">true</g' $AODEVF
	sed -i 's/name="support_agps_roaming">false</name="support_agps_roaming">true</g' $AODEVF
	sed -i 's/name="support_wifi_low_latency_mode">false</name="support_wifi_low_latency_mode">true</g' $AODEVF
	sed -i 's/name="support_network_rps_mode">false</name="support_network_rps_mode">true</g' $AODEVF
	sed -i 's/name="support_camera_peaking_mf">false</name="support_camera_peaking_mf">true</g' $AODEVF
	sed -i 's/name="support_camera_4k_quality">false</name="support_camera_4k_quality">true</g' $AODEVF
	sed -i 's/name="support_camera_8k_quality">false</name="support_camera_8k_quality">true</g' $AODEVF
	sed -i 's/name="support_zoom_mfnr">false</name="support_zoom_mfnr">true</g' $AODEVF
	sed -i 's/name="support_mfnr">false</name="support_mfnr">true</g' $AODEVF
	sed -i 's/name="support_camera_mfnr">false</name="support_camera_mfnr">true</g' $AODEVF
	sed -i 's/name="support_front_beauty_mfnr">false</name="support_front_beauty_mfnr">true</g' $AODEVF
	sed -i 's/name="support_video_hfr_mode">false</name="support_video_hfr_mode">true</g' $AODEVF
	sed -i 's/name="support_chroma_flash">false</name="support_chroma_flash">true</g' $AODEVF
	sed -i 's/name="support_object_track">false</name="support_object_track">true</g' $AODEVF
	sed -i 's/name="support_psensor_pocket_mode">false</name="support_psensor_pocket_mode">true</g' $AODEVF
	sed -i 's/name="is_camera_hide_hht_menu">true</name="is_camera_hide_hht_menu">false</g' $AODEVF
	sed -i 's/name="is_camera_replace_higher_cost_effect">true</name="is_camera_replace_higher_cost_effect">false</g' $AODEVF
	sed -i 's/name="camera_adjust_picture_size_enabled">true</name="camera_adjust_picture_size_enabled">false</g' $AODEVF
	sed -i 's/name="support_display_expert_mode">false</name="support_display_expert_mode">true</g' $AODEVF
	sed -i 's/name="support_screen_enhance_engine">false</name="support_screen_enhance_engine">true</g' $AODEVF
	sed -i 's/name="support_true_color">false</name="support_true_color">true</g' $AODEVF
	sed -i 's/name="support_videobox_display_effect">false</name="support_videobox_display_effect">true</g' $AODEVF
	sed -i 's/name="is_support_video_tool_box">false</name="is_support_video_tool_box">true</g' $AODEVF
	sed -i 's/name="support_displayfeature_gamemode">false</name="support_displayfeature_gamemode">true</g' $AODEVF
	sed -i 's/name="support_secret_dc_backlight">false</name="support_secret_dc_backlight">true</g' $AODEVF
	sed -i 's/name="hide_flicker_backlight">true</name="hide_flicker_backlight">false</g' $AODEVF
	sed -i 's/name="support_AI_display">false</name="support_AI_display">true</g' $AODEVF
	sed -i 's/name="support_truetone">false</name="support_truetone">true</g' $AODEVF
	sed -i 's/name="support_power_mode">true</name="support_power_mode">false</g' $AODEVF
	sed -i 's/name="support_extreme_battery_saver">false</name="support_extreme_battery_saver">true</g' $AODEVF
	sed -i 's/name="support_gallery_hdr">false</name="support_gallery_hdr">true</g' $AODEVF
	sed -i 's/name="support_hdr_enhance">false</name="support_hdr_enhance">true</g' $AODEVF
	sed -i 's/name="gallery_support_media_feature">false</name="gallery_support_media_feature">true</g' $AODEVF
	sed -i 's/name="gallery_support_video_compress">false</name="gallery_support_video_compress">true</g' $AODEVF
	sed -i 's/name="gallery_support_analytic_face_and_scene">false</name="gallery_support_analytic_face_and_scene">true</g' $AODEVF
	sed -i 's/name="gallery_support_time_burst_video">false</name="gallery_support_time_burst_video">true</g' $AODEVF
	sed -i 's/name="support_local_ocr">false</name="support_local_ocr">true</g' $AODEVF
	sed -i 's/name="gallery_support_dolby">false</name="gallery_support_dolby">true</g' $AODEVF
	sed -i 's/name="optimize_wakelock_enabled">false</name="optimize_wakelock_enabled">true</g' $AODEVF
	sed -i 's/name="support_google_rsa_protocol">false</name="support_google_rsa_protocol">true</g' $AODEVF
	sed -i '/<features>/a\
	<bool name="support_AI_display">true</bool>\
	<bool name="support_screen_enhance_engine">true</bool>\
	<bool name="support_zoom_mfnr">true</bool>\
	<bool name="support_mfnr">true</bool>\
	<bool name="support_camera_mfnr">true</bool>\
	<bool name="support_camera_4k_quality">true</bool>\
	<bool name="support_camera_8k_quality">true</bool>\
	<bool name="support_gallery_hdr">true</bool>\
	<bool name="support_hdr_enhance">true</bool>\
	<bool name="gallery_support_media_feature">true</bool>\
	<bool name="gallery_support_video_compress">true</bool>\
	<bool name="gallery_support_analytic_face_and_scene">true</bool>\
	<bool name="gallery_support_time_burst_video">true</bool>\
	<bool name="support_local_ocr">true</bool>\
	<bool name="gallery_support_dolby">true</bool>\
	<bool name="optimize_wakelock_enabled">true</bool>\
	<bool name="support_google_rsa_protocol">true</bool>\
	<bool name="is_camera_hide_hht_menu">false</bool>' $AODEVF
	sed -i '/^ *#/d; /^ *$/d' $AODEVF
	done

	settings put global dropbox_max_files 1
	settings put global ntp_server europe.pool.ntp.org
	settings put system oneplus_lab_feature_key 1
	settings put system miui_recents_show_recommend 0

	prop_process $MODPATH/common/other.prop
fi

ui_print " - Installing Main Patches -"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "*          General changes for All devices.       *"
  ui_print "*  Including maximum sound quality, Bass Booster, *"
  ui_print "* Hi-Fi parametrs, Dolby Surround parametrs, etc. *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "*    Installation time of this item ≈5-10 min     *"
  ui_print "*                 Please, wait...                 *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print " "

  for OACONF in ${ACONFS}; do
	ACONF="$MODPATH$(echo $OACONF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OACONF $ACONF
	sed -i 's/\t/  /g' $ACONF
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d; /^ *#/d; /^ *$/d' $ACONF
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_WB_SPEECH_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_AUDIO_HD_REC_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_DUAL_MIC_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_HANDSFREE_DMNR_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_VOIP_ENHANCEMENT_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_ASR_SUPPORT"]' "no"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_VOICE_UNLOCK_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_SPEAKER_MONITOR_SUPPORT"]' "no"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_HAC_SUPPORT"]' "no"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_AURISYS_FRAMEWORK_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_AUDIO_TUNING_TOOL_VERSION"]' "V5"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_AUDIO_TUNNELING_SUPPORT"]' "no"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_HIFIAUDIO_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_BESLOUDNESS_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_A2DP_OFFLOAD_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_TTY_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_AUDIO_A2DP_LATENCY_IMPROVE"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_VOW_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_AUDIODSP_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="FIX_WB_ENH"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_BT_HEARING_AID_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="RCV_PATH_NO_ANA"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="SPK_PATH_NO_ANA"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="VIR_MTK_USB_PHONECALL"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_VOW_AMAZON_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_AUDIO_GAME_VOICE_SUPPORT"]' "yes"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_IIR_ENH_SUPPORT"]' "no"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_IIR_MIC_SUPPORT"]' "no"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="MTK_FIR_IIR_ENH_SUPPORT"]' "no"
	AIST_proc -u $ACONF '/AudioParamOptions/Param[@name="VIR_SCENE_CUSTOMIZATION_SUPPORT"]' "yes"
	sed -i '/^ *#/d; /^ *$/d' $ACONF
	done

  for OMEDCX in ${MEDCA}; do
	MEDCX="$MODPATH$(echo $OMEDCX | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OMEDCX $MEDCX
	sed -i 's/\t/  /g' $MEDCX
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d; /^ *#/d; /^ *$/d' $MEDCX
	sed -i 's/name="sample-rate" ranges="8000,11025,12000,16000,22050,24000,32000,44100,48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="32000,44100,48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="7350,8000,11025,12000,16000,22050,24000,32000,44100,48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="8000-48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="8000-96000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="8000-192000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="bitrate-modes" value="CBR"/name="bitrate-modes" value="CQ"/g' $MEDCX
	sed -i 's/name="complexity" range="0-10"  default="9"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-10"  default="8"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-10"  default="7"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-10"  default="6"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-8"  default="7"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-8"  default="6"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-8"  default="5"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-8"  default="4"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="quality" range="0-80"  default="100"/name="quality" range="0-100"  default="100"/g' $MEDCX
	sed -i 's/name="bitrate" range="8000-320000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="8000-960000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="32000-500000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="6000-510000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="1-10000000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="500-512000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="32000-640000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="32000-6144000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="16000-2688000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="64000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i '/^ *#/d; /^ *$/d' $MEDCX
	done
